Scotland_areas is a coarse grained version of 
"Local Authority Districts (December 2019) Boundaries UK BFC"

downloaded from:

https://geoportal.statistics.gov.uk/datasets/local-authority-districts-december-2019-boundaries-uk-bfc/explore?location=52.400312%2C-0.672737%2C6.00
