
#include "gitversion.hh"

#include <string>

using namespace std;

string gitversion()
{
    return GIT_VERSION;
}
